<?php

echo hash('sha512','1234');
?>