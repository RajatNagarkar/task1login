<?php
    class CreateUser{
        private $usr, $fullName, $pass;
        function __construct(){
            $this->validateData();
        }
        private function validateData(){
            if(strlen(checkData('username'))<7){
                // echo "";
                exit("ExU34A6");
            }
            if(strlen(checkData('pass'))<7){
                // echo "";
                exit("T4xP404");
            }
        }
        private function checkData($fieldName){
            if(isset($fieldName) === false){
                return '';
            }
            return htmlspecialchars(stripslashes($_POST[$fieldName]));
        }
    }
?>